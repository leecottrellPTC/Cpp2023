#include "IndexNode.h"

IndexNode::IndexNode()
{

}

IndexNode::~IndexNode()
{

}